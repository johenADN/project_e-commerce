# **Rauans'shop Shop - eCommerce Site in Django Python**


**Log on to codeastro.com for more projects!**

**Developed By Rauan Gadil**

## **Instructions**
- Install the Requirements: pip install -r requirements.txt
- Then, make database migrations: python manage.py makemigrations
- python manage.py migrate
- And finally, run the application: python manage.py runserver

For Admin Account, please create one with superuser!

------------------------------------------------------------
- **Developed by:** Rauan Gadil
------------------------------------------------------------
- **Customized by:** Rauan Gadil
------------------------------------------------------------

------------------------------------------------------------
## Admin Access
- **Username:** admin
- **Password:** admin123